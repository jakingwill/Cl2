from django.contrib import admin

from .models import Job

admin.site.register(Job)

from .models import Employer, Jobseeker

admin.site.register(Employer)

admin.site.register(Jobseeker)
