from django.apps import AppConfig


class ClockworkConfig(AppConfig):
    name = 'clockwork'
